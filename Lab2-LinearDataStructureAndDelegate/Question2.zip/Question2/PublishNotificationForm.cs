﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Question2
{
    public partial class PublishNotificationForm : Form
    {
        private List<INotificationSender> subscribers;
        private List<SendViaEmail> emailSubscribers;
        private List<SendViaMobile> mobileSubscribers;

        // Add field for txtMessage
        private TextBox txtMessage;

        public PublishNotificationForm(List<INotificationSender> subscribers)
        {
            InitializeComponent();
            this.subscribers = subscribers;
            this.emailSubscribers = new List<SendViaEmail>();
            this.mobileSubscribers = new List<SendViaMobile>();

            // Enable publish button only if there's at least one subscriber
            btnPublish.Enabled = subscribers.Count > 0;
        }

        public PublishNotificationForm(List<SendViaEmail> emailSubscribers, List<SendViaMobile> mobileSubscribers)
        {
            InitializeComponent();
            this.emailSubscribers = emailSubscribers;
            this.mobileSubscribers = mobileSubscribers;
            this.subscribers = new List<INotificationSender>();
            this.subscribers.AddRange(emailSubscribers);
            this.subscribers.AddRange(mobileSubscribers);
        }

        private void btnPublish_Click(object sender, EventArgs e)
        {
            string message = txtMessage.Text.Trim();

            if (string.IsNullOrEmpty(message))
            {
                MessageBox.Show("Please enter a message to publish.");
                return;
            }

            foreach (var subscriber in subscribers)
            {
                subscriber.SendNotification(message);
            }

            MessageBox.Show("Notification sent to all subscribers!");
            txtMessage.Clear();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
