﻿namespace Question2
{
    public interface INotificationSender
    {
        void SendNotification(string message);
    }
}
