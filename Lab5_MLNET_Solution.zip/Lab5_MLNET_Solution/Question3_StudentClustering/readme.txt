Attribute Information:
STG (The degree of study time for goal object materails);
SCG (The degree of repetition number of user for goal object materails);
STR (The degree of study time of user for related objects with goal object);
LPR (The exam performance of user for related objects with goal object);
PEG (The exam performance of user for goal objects);
UNS (The knowledge level of user)
